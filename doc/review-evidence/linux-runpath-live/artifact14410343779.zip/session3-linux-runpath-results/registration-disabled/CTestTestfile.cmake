# CMake generated Testfile for 
# Source directory: /home/runner/work/btx/btx/contrib/devtools/session3-linux-runpath/live-qualification
# Build directory: /home/runner/work/_temp/session3-linux-runpath-results/registration-disabled
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[util_rpcauth_test]=] "/usr/bin/python3" "/home/runner/work/_temp/session3-linux-runpath-results/registration-disabled/test/util/rpcauth-test.py")
set_tests_properties([=[util_rpcauth_test]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/runner/work/_temp/session3-linux-runpath-results/sources/after/cmake/tests.cmake;12;add_test;/home/runner/work/_temp/session3-linux-runpath-results/sources/after/cmake/tests.cmake;0;;/home/runner/work/btx/btx/contrib/devtools/session3-linux-runpath/live-qualification/CMakeLists.txt;11;include;/home/runner/work/btx/btx/contrib/devtools/session3-linux-runpath/live-qualification/CMakeLists.txt;0;")
add_test([=[matmul_v4_full_benchmark_wrapper]=] "/usr/bin/python3" "/home/runner/work/_temp/session3-linux-runpath-results/sources/after/contrib/matmul-v4/test_run_full_benchmark.py")
set_tests_properties([=[matmul_v4_full_benchmark_wrapper]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/runner/work/_temp/session3-linux-runpath-results/sources/after/cmake/tests.cmake;16;add_test;/home/runner/work/_temp/session3-linux-runpath-results/sources/after/cmake/tests.cmake;0;;/home/runner/work/btx/btx/contrib/devtools/session3-linux-runpath/live-qualification/CMakeLists.txt;11;include;/home/runner/work/btx/btx/contrib/devtools/session3-linux-runpath/live-qualification/CMakeLists.txt;0;")
