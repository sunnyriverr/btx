#!/usr/bin/env python3
"""Unit coverage for scripts/release/package_release_archive.py."""

from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tarfile
import tempfile
import types
import unittest
import zipfile
from unittest import mock


ROOT = pathlib.Path(__file__).resolve().parents[2]
SCRIPT_PATH = ROOT / "scripts" / "release" / "package_release_archive.py"


def load_module():
    spec = importlib.util.spec_from_file_location("package_release_archive", SCRIPT_PATH)
    assert spec is not None
    assert spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def load_make_elf():
    """The minimal ELF builder the archive gate tests already use."""
    path = ROOT / "test" / "util" / "verify_release_btxd_test.py"
    spec = importlib.util.spec_from_file_location("verify_release_btxd_test", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.make_elf


class PackageReleaseArchiveTest(unittest.TestCase):
    def setUp(self):
        self.module = load_module()

    def _build_source_root(self, root: pathlib.Path) -> pathlib.Path:
        source_root = root / "source-root"
        for relative_path in self.module.SUPPORT_FILES:
            path = source_root / relative_path
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(f"{relative_path}\n", encoding="utf-8")
        return source_root

    def _write_binaries(self, root: pathlib.Path, *, windows: bool = False) -> tuple[pathlib.Path, pathlib.Path]:
        suffix = ".exe" if windows else ""
        btxd = root / f"btxd{suffix}"
        btx_cli = root / f"btx-cli{suffix}"
        btx_util = root / f"btx-util{suffix}"
        btxd.write_text("daemon\n", encoding="utf-8")
        btx_cli.write_text("cli\n", encoding="utf-8")
        btx_util.write_text("util\n", encoding="utf-8")
        return btxd, btx_cli

    def _stub_ship_gate(self):
        self.module.verify_shipped_btxd = lambda path: None
        self.module.verify_shipped_cli = lambda path: None
        self.module.verify_shipped_macos_cli = lambda path: None
        self.module.verify_shipped_helper = lambda path: None
        # Text fixtures do not exercise ELF editing; native loader coverage below does.
        self.module.set_linux_bundled_lib_runpath = lambda path: None

    def test_linux_archive_includes_binaries_and_helpers(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            output_dir = root / "out"

            exit_code = self.module.main(
                [
                    "--output-dir",
                    str(output_dir),
                    "--version",
                    "29.2",
                    "--platform-id",
                    "linux-x86_64",
                    "--btxd",
                    str(btxd),
                    "--btx-cli",
                    str(btx_cli),
                    "--source-root",
                    str(source_root),
                ]
            )

            self.assertEqual(exit_code, 0)
            archive_path = output_dir / "btx-29.2-x86_64-linux-gnu.tar.gz"
            self.assertTrue(archive_path.is_file())
            with tarfile.open(archive_path, "r:gz") as archive:
                names = set(archive.getnames())
                self.assertIn("btx-29.2/bin/btxd", names)
                self.assertIn("btx-29.2/bin/btx-cli", names)
                self.assertIn("btx-29.2/libexec/btxd.real", names)
                self.assertIn("btx-29.2/libexec/btx-cli.real", names)
                self.assertIn("btx-29.2/contrib/faststart/btx-faststart.py", names)
                self.assertIn("btx-29.2/contrib/mining/start-live-mining.sh", names)
                self.assertIn("btx-29.2/doc/btx-download-and-go.md", names)
                self.assertIn("btx-29.2/contrib/modelnet/btx-model", names)
                self.assertIn("btx-29.2/doc/modelnet/registry-independence.md", names)
                self.assertIn("btx-29.2/doc/release-notes/release-notes-0.34.9-dev.md", names)
                # 0.34.16 shipped only the 0.34.9-0.34.11 notes; ship this release's own.
                self.assertIn("btx-29.2/doc/release-notes-0.34.16.md", names)

                wrapper = archive.extractfile("btx-29.2/bin/btxd")
                assert wrapper is not None
                wrapper_text = wrapper.read().decode("utf-8")
                self.assertIn("missing runtime libraries", wrapper_text)
                self.assertIn("objdump -T", wrapper_text)
                self.assertIn("GLIBCXX", wrapper_text)
                self.assertIn("BTX_GLIBC_PREFIX", wrapper_text)
                self.assertIn("libgomp1", wrapper_text)
                self.assertIn("OPENSSL", wrapper_text)
                self.assertIn("LIB_DIR", wrapper_text)

    def test_require_gui_rejects_archive_without_btx_qt(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            with self.assertRaises(FileNotFoundError):
                self.module.main(
                    [
                        "--output-dir",
                        str(root / "out"),
                        "--version",
                        "29.2",
                        "--platform-id",
                        "linux-x86_64",
                        "--btxd",
                        str(btxd),
                        "--btx-cli",
                        str(btx_cli),
                        "--source-root",
                        str(source_root),
                        "--require-gui",
                    ]
                )

    def test_guard_remains_a_regular_daemon_sibling_after_extraction(self):
        self._stub_ship_gate()
        runpath_targets = []
        self.module.set_linux_bundled_lib_runpath = runpath_targets.append
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            guard_bytes = b"guard executable\n"
            (root / "btx-guardd").write_bytes(guard_bytes)
            original_epoch = os.environ.get("SOURCE_DATE_EPOCH")
            os.environ["SOURCE_DATE_EPOCH"] = "1712534400"
            try:
                for platform_id in ("linux-x86_64", "linux-arm64", "macos-x86_64", "macos-arm64"):
                    archives = []
                    for attempt in ("first", "second"):
                        staged, included, _ = self.module.stage_release_tree(
                            version="29.2", platform_id=platform_id,
                            btxd_path=btxd, btx_cli_path=btx_cli, btx_util_path=None,
                            matmul_metallib_path=None, oracle_metallib_path=None,
                            metal_lib_dir=None, source_root=source_root,
                            temp_root=root / platform_id / attempt,
                        )
                        sibling = staged / "libexec/btx-guardd"
                        real_guard = staged / "libexec/btx-guardd.real"
                        # The RUNPATH edit is ELF-only; a macOS guard is Mach-O.
                        self.assertEqual(runpath_targets, [real_guard] if platform_id.startswith("linux-") else [])
                        runpath_targets.clear()
                        self.assertTrue(sibling.is_file())
                        self.assertFalse(sibling.is_symlink())
                        self.assertTrue(sibling.samefile(real_guard))
                        self.assertIn("libexec/btx-guardd", included)
                        self.assertEqual(sibling.read_bytes(), guard_bytes)
                        self.assertEqual(sibling.stat().st_mode & 0o777, 0o755)
                        self.assertEqual(
                            (staged / "bin/btx-guardd").read_text(),
                            self.module.wrapper_payload("btx-guardd", platform_id),
                        )
                        archive_path = root / platform_id / (attempt + ".tar.gz")
                        self.module.write_tar_gz(archive_path, staged)
                        archives.append(archive_path.read_bytes())
                        extracted = root / platform_id / (attempt + "-extracted")
                        with tarfile.open(archive_path) as archive:
                            # This fixture generated every member above; retain
                            # support for Python versions before data_filter.
                            options = {"filter": "data"} if hasattr(tarfile, "data_filter") else {}
                            archive.extractall(extracted, **options)
                        for name in ("btx-guardd", "btx-guardd.real"):
                            actual = extracted / "btx-29.2/libexec" / name
                            self.assertTrue(actual.is_file())
                            self.assertFalse(actual.is_symlink())
                            self.assertEqual(actual.read_bytes(), guard_bytes)
                            self.assertEqual(actual.stat().st_mode & 0o777, 0o755)
                    self.assertEqual(archives[0], archives[1])
            finally:
                if original_epoch is None:
                    os.environ.pop("SOURCE_DATE_EPOCH", None)
                else:
                    os.environ["SOURCE_DATE_EPOCH"] = original_epoch

    def test_qt_only_wrapper_uses_private_libraries(self):
        qt = self.module.wrapper_payload("btx-qt", "linux-x86_64")
        self.assertIn('LD_LIBRARY_PATH="$SELF_DIR/../lib/qt-private:$LIB_DIR', qt)
        self.assertIn('PLUGIN_DIR="$SELF_DIR/../lib/qt-private/qt6/plugins"', qt)
        for name in ("btxd", "btx-atlas", "btx-guardd"):
            self.assertNotIn("qt-private", self.module.wrapper_payload(name, "linux-x86_64"))

    @unittest.skipUnless(sys.platform.startswith("linux") and shutil.which("cc") and shutil.which("patchelf"),
                         "native Linux ELF tools required")
    def test_direct_guard_and_qt_keep_shared_and_private_dependencies(self):
        self.module.verify_shipped_btxd = lambda path: None
        self.module.verify_shipped_cli = lambda path: None
        bundle_path = SCRIPT_PATH.with_name("bundle_qt_gui.py")
        spec = importlib.util.spec_from_file_location("native_bundle_fixture", bundle_path)
        bundle = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(bundle)
        self.module._load_qt_bundle = lambda: bundle
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, cli = self._write_binaries(root)
            buildlib = root / "buildlib"; buildlib.mkdir()
            plugins = root / "plugins"; (plugins / "platforms").mkdir(parents=True)
            def library(name, code, deps=()):
                c = root / (name + ".c"); c.write_text(code)
                target = buildlib / name
                subprocess.run(["cc", "-shared", "-fPIC", str(c), "-L" + str(buildlib),
                                *["-l:" + d for d in deps], "-Wl,-soname," + name,
                                "-Wl,-rpath,$ORIGIN", "-o", str(target)], check=True)
                return target
            library("libbtxsharedchild.so.1", "int child(void) { return 17; }\n")
            library("libbtxshared.so.1", "extern int child(void); int shared(void) { return child(); }\n",
                    ["libbtxsharedchild.so.1"])
            library("libbtxprivate.so.1", "int private_value(void) { return 4; }\n")
            qt = library("libQt6Core.so.6", "extern int shared(void), private_value(void); int qt_value(void) { return shared()+private_value(); }\n",
                         ["libbtxshared.so.1", "libbtxprivate.so.1"])
            plugin = library("libqxcb.so", "extern int qt_value(void); int plugin(void) { return qt_value(); }\n", [qt.name])
            shutil.copy2(plugin, plugins / "platforms/libqxcb.so")
            subprocess.run(["patchelf", "--set-rpath", str(buildlib), str(plugins / "platforms/libqxcb.so")], check=True)
            bundle._qt_plugins_root = lambda: plugins
            for name, code, dep in (("btx-guardd", "extern int shared(void); int main(void) { return shared()==17 ? 0 : 2; }\n", "libbtxshared.so.1"),
                                    ("btx-qt", "extern int qt_value(void); int main(void) { return qt_value()==21 ? 0 : 3; }\n", qt.name)):
                c = root / (name + ".c");c.write_text(code)
                subprocess.run(["cc", str(c), "-L" + str(buildlib), "-l:" + dep,
                                "-Wl,-rpath," + (str(buildlib) if name == "btx-qt" else "$ORIGIN/buildlib"), "-Wl,-rpath-link," + str(buildlib),
                                "-o", str(root / name)], check=True)
            shared_consumers = ("btx-atlas", "btx-native-qualify", "btx-security")
            source = root / "shared_consumer.c"
            source.write_text("extern int shared(void); int main(void) { return shared()==17 ? 0 : 2; }\n")
            for name in shared_consumers:
                subprocess.run(["cc", str(source), "-L" + str(buildlib), "-l:libbtxshared.so.1",
                                "-Wl,-rpath-link," + str(buildlib), "-o", str(root / name)], check=True)
            original_binaries = {name: (root / name).read_bytes() for name in shared_consumers}

            # Text daemon/CLI fixtures have no ELF dependencies. Do not fake the Qt/guard graphs.
            actual_ldd, actual_needed = bundle._ldd_map, getattr(bundle, "_needed", lambda path: set())
            text_fixtures = (btxd, cli, root / "btx-util")
            bundle._needed = lambda path: set() if path in text_fixtures else actual_needed(path)
            bundle._ldd_map = lambda path, *args: {} if path in text_fixtures else actual_ldd(path, *args)
            # The producer can find its libraries during staging. The extracted
            # release must find its own libraries without that environment.
            with mock.patch.dict(os.environ, {"LD_LIBRARY_PATH": str(buildlib)}):
                staged, _, _ = self.module.stage_release_tree(
                    version="29.2", platform_id="linux-x86_64", btxd_path=btxd, btx_cli_path=cli,
                    btx_util_path=None, matmul_metallib_path=None, oracle_metallib_path=None,
                    metal_lib_dir=None, source_root=source_root, temp_root=root / "staged")
            guard = staged / "libexec/btx-guardd"
            self.assertTrue(guard.samefile(staged / "libexec/btx-guardd.real"))
            for name in ("libbtxshared.so.1", "libbtxsharedchild.so.1"):
                self.assertTrue((staged / "lib" / name).is_file())
            clean_env = {k: v for k, v in os.environ.items() if not k.startswith("LD_")}
            for binary in (guard, staged / "libexec/btx-qt.real"):
                result = subprocess.run([str(binary)], env=clean_env, capture_output=True, timeout=5)
                self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))
            self.assertTrue((staged / "lib/qt-private/libbtxprivate.so.1").is_file())
            self.assertFalse((staged / "lib/libbtxprivate.so.1").exists())
            archive = root / "guard.tar.gz"
            self.module.write_tar_gz(archive, staged)
            with tarfile.open(archive) as tar:
                options = {"filter": "data"} if hasattr(tarfile, "data_filter") else {}
                tar.extractall(root / "restored", **options)
            restored = root / "restored/btx-29.2/libexec/btx-guardd"
            self.assertFalse(restored.is_symlink())
            self.assertTrue(restored.samefile(restored.with_name("btx-guardd.real")))
            self.assertEqual(subprocess.run([str(restored)], env=clean_env, capture_output=True, timeout=5).returncode, 0)
            for name in shared_consumers:
                with self.subTest(binary=name):
                    self.assertEqual((root / name).read_bytes(), original_binaries[name])
                    binary = restored.with_name(name + ".real")
                    result = subprocess.run([str(binary)], env=clean_env, capture_output=True, timeout=5)
                    self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))

    def test_require_model_helpers_rejects_archive_without_them(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            argv = ["--output-dir", str(root / "out"), "--version", "29.2",
                    "--platform-id", "linux-x86_64", "--btxd", str(btxd),
                    "--btx-cli", str(btx_cli), "--source-root", str(source_root),
                    "--require-model-helpers"]
            (root / "modelnet").mkdir()
            for name in self.module.MODEL_HELPER_BINARIES[:-1]:
                (root / "modelnet" / name).write_text("helper\n", encoding="utf-8")
            with self.assertRaises(FileNotFoundError) as caught:
                self.module.main(argv)
            self.assertIn("btx-matmul-backend-info", str(caught.exception))
            (root / "btx-matmul-backend-info").write_text("helper\n", encoding="utf-8")
            self.assertEqual(self.module.main(argv), 0)

    def test_cuda_archive_names_match_release_platform_ids(self):
        self.assertEqual(
            self.module.archive_filename("0.33.0", "linux-x86_64-cuda12", None),
            "btx-0.33.0-x86_64-linux-gnu-cuda12.tar.gz",
        )
        self.assertEqual(
            self.module.archive_filename("0.33.0", "linux-x86_64-cuda13", None),
            "btx-0.33.0-x86_64-linux-gnu-cuda13.tar.gz",
        )

    def test_windows_archive_uses_zip_and_exe_names(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root, windows=True)
            output_dir = root / "out"

            exit_code = self.module.main(
                [
                    "--output-dir",
                    str(output_dir),
                    "--version",
                    "29.2",
                    "--platform-id",
                    "windows-x86_64",
                    "--btxd",
                    str(btxd),
                    "--btx-cli",
                    str(btx_cli),
                    "--source-root",
                    str(source_root),
                ]
            )

            self.assertEqual(exit_code, 0)
            archive_path = output_dir / "btx-29.2-x86_64-w64-mingw32.zip"
            self.assertTrue(archive_path.is_file())
            with zipfile.ZipFile(archive_path) as archive:
                names = set(archive.namelist())
            self.assertIn("btx-29.2/bin/btxd.exe", names)
            self.assertIn("btx-29.2/bin/btx-cli.exe", names)
            self.assertIn("btx-29.2/contrib/faststart/btx-agent-setup.py", names)

    def test_stage_release_tree_rejects_missing_support_file(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = root / "source-root"
            source_root.mkdir()
            btxd, btx_cli = self._write_binaries(root)

            with self.assertRaises(FileNotFoundError):
                self.module.stage_release_tree(
                    version="29.2",
                    platform_id="linux-x86_64",
                    btxd_path=btxd,
                    btx_cli_path=btx_cli,
                    btx_util_path=None,
                    matmul_metallib_path=None,
                    oracle_metallib_path=None,
                    metal_lib_dir=None,
                    source_root=source_root,
                    temp_root=root / "temp",
                )

    def test_tarball_is_reproducible_with_source_date_epoch(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            output_a = root / "out-a"
            output_b = root / "out-b"

            original_epoch = os.environ.get("SOURCE_DATE_EPOCH")
            os.environ["SOURCE_DATE_EPOCH"] = "1712534400"
            try:
                self.module.main(
                    [
                        "--output-dir",
                        str(output_a),
                        "--version",
                        "29.2",
                        "--platform-id",
                        "linux-x86_64",
                        "--btxd",
                        str(btxd),
                        "--btx-cli",
                        str(btx_cli),
                        "--source-root",
                        str(source_root),
                    ]
                )
                self.module.main(
                    [
                        "--output-dir",
                        str(output_b),
                        "--version",
                        "29.2",
                        "--platform-id",
                        "linux-x86_64",
                        "--btxd",
                        str(btxd),
                        "--btx-cli",
                        str(btx_cli),
                        "--source-root",
                        str(source_root),
                    ]
                )
            finally:
                if original_epoch is None:
                    os.environ.pop("SOURCE_DATE_EPOCH", None)
                else:
                    os.environ["SOURCE_DATE_EPOCH"] = original_epoch

            archive_a = output_a / "btx-29.2-x86_64-linux-gnu.tar.gz"
            archive_b = output_b / "btx-29.2-x86_64-linux-gnu.tar.gz"
            self.assertEqual(archive_a.read_bytes(), archive_b.read_bytes())

    def test_ship_target_aliases_share_canonical_triples(self):
        self.assertEqual(
            self.module.archive_filename("0.34.5", "linux-x86_64-cpu", None),
            self.module.archive_filename("0.34.5", "linux-x86_64", None),
        )
        self.assertEqual(
            self.module.archive_filename("0.34.5", "macos-arm64-metal", None),
            self.module.archive_filename("0.34.5", "macos-arm64", None),
        )
        self.assertEqual(
            self.module.archive_filename("0.34.5", "linux-x86_64-cuda12", None),
            "btx-0.34.5-x86_64-linux-gnu-cuda12.tar.gz",
        )
        self.assertEqual(
            self.module.archive_filename("0.34.5", "linux-x86_64-cuda", None),
            self.module.archive_filename("0.34.5", "linux-x86_64-cuda12", None),
        )

    def test_macos_metal_archive_includes_modelnet_helpers_and_metallibs(self):
        self._stub_ship_gate()
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            (root / "btx-modeld").write_text("modeld\n", encoding="utf-8")
            (root / "btx-modelcheck").write_text("modelcheck\n", encoding="utf-8")
            (root / "btx-open").write_text("open\n", encoding="utf-8")
            (root / "btx-matmul-backend-info").write_text("backend\n", encoding="utf-8")
            metal_dir = root / "metallibs"
            metal_dir.mkdir()
            (metal_dir / "matmul_accel_kernels.metallib").write_bytes(b"metal")
            (metal_dir / "matmul_v4_rc_rowleaf_gpu_kernels.metallib").write_bytes(b"rowleaf")
            output_dir = root / "out"

            exit_code = self.module.main(
                [
                    "--output-dir",
                    str(output_dir),
                    "--version",
                    "0.34.7",
                    "--platform-id",
                    "macos-arm64-metal",
                    "--btxd",
                    str(btxd),
                    "--btx-cli",
                    str(btx_cli),
                    "--metal-lib-dir",
                    str(metal_dir),
                    "--source-root",
                    str(source_root),
                ]
            )

            self.assertEqual(exit_code, 0)
            archive_path = output_dir / "btx-0.34.7-arm64-apple-darwin.tar.gz"
            self.assertTrue(archive_path.is_file())
            with tarfile.open(archive_path, "r:gz") as archive:
                names = set(archive.getnames())
            self.assertIn("btx-0.34.7/libexec/btx-modeld.real", names)
            self.assertIn("btx-0.34.7/bin/btx-modeld", names)
            self.assertIn("btx-0.34.7/libexec/btx-open.real", names)
            self.assertIn("btx-0.34.7/libexec/btx-matmul-backend-info.real", names)
            self.assertIn("btx-0.34.7/libexec/metal/matmul_accel_kernels.metallib", names)
            self.assertIn(
                "btx-0.34.7/libexec/metal/matmul_v4_rc_rowleaf_gpu_kernels.metallib", names
            )

    def test_macos_checks_finished_images_after_runtime_bundling(self):
        # A build input can legitimately link Homebrew Python. Only the final
        # staged images may pass the shipping gate; a bad bundle must fail closed.
        for broken in (None, "btxd.real", "btx-cli.real", "btx-util.real", "btx-modeld.real"):
            with self.subTest(broken=broken), tempfile.TemporaryDirectory() as tmpdir:
                root = pathlib.Path(tmpdir)
                source_root = self._build_source_root(root)
                btxd, cli = self._write_binaries(root)
                (root / "btx-modeld").write_text("producer dependency\n")
                checked = []
                def gate(path):
                    if path.parent.name != "libexec" or path.read_text() != "bundled\n":
                        raise RuntimeError("unrelocated producer dependency")
                    checked.append(path.name)
                    if path.name == broken:
                        raise RuntimeError("invalid final image")
                self.module.verify_shipped_btxd = gate
                self.module.verify_shipped_cli = gate
                self.module.verify_shipped_helper = gate
                def bundle(release_root, **kwargs):
                    for image in (release_root / "libexec").glob("*.real"):
                        image.write_text("bundled\n")
                    return []
                fake = types.ModuleType("bundle_macos_python_runtime")
                fake.bundle_macos_python = bundle
                spec = importlib.machinery.ModuleSpec("bundle_macos_python_runtime",
                    types.SimpleNamespace(create_module=lambda spec: fake, exec_module=lambda module: None))
                original_spec = importlib.util.spec_from_file_location
                def select_spec(name, path, *args, **kwargs):
                    if pathlib.Path(path).name == "bundle_macos_python_runtime.py":
                        return spec
                    return original_spec(name, path, *args, **kwargs)
                args = ["--output-dir", str(root / "out"), "--version", "test",
                        "--platform-id", "macos-arm64", "--btxd", str(btxd),
                        "--btx-cli", str(cli), "--source-root", str(source_root)]
                with mock.patch.object(self.module.importlib.util, "spec_from_file_location", side_effect=select_spec):
                    if broken:
                        with self.assertRaisesRegex(RuntimeError, "invalid final image"):
                            self.module.main(args)
                        self.assertFalse(list((root / "out").glob("*.tar.gz")))
                    else:
                        self.assertEqual(self.module.main(args), 0)
                        self.assertEqual(set(checked), {"btxd.real", "btx-cli.real", "btx-util.real", "btx-modeld.real"})
                        self.assertTrue(list((root / "out").glob("*.tar.gz")))

    def test_verify_shipped_btxd_refuses_unrecognized_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            btxd = pathlib.Path(tmpdir) / "btxd"
            btxd.write_text("daemon\n", encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "unrecognized file"):
                self.module.verify_shipped_btxd(btxd)

    def test_verify_shipped_cli_refuses_unrecognized_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            cli = pathlib.Path(tmpdir) / "btx-cli"
            cli.write_text("cli\n", encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "unrecognized file"):
                self.module.verify_shipped_cli(cli)

    def test_packaging_refuses_text_stub_btxd(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd, btx_cli = self._write_binaries(root)
            with self.assertRaisesRegex(RuntimeError, "unrecognized file"):
                self.module.main(
                    [
                        "--output-dir",
                        str(root / "out"),
                        "--version",
                        "0.34.5",
                        "--platform-id",
                        "linux-x86_64-cpu",
                        "--btxd",
                        str(btxd),
                        "--btx-cli",
                        str(btx_cli),
                        "--source-root",
                        str(source_root),
                    ]
                )

    def test_packaging_refuses_btxd_built_without_zmq(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            source_root = self._build_source_root(root)
            btxd = root / "btxd"
            btx_cli = root / "btx-cli"
            btx_util = root / "btx-util"
            # ELF magic + hidden-arg string, no ENABLE_ZMQ help: 0.33.4.2 CPU shape.
            btxd.write_bytes(b"\x7fELF" + b"\x00" * 12 + b"-zmqpubhashblock\x00")
            btx_cli.write_bytes(b"\x7fELF" + b"\x00" * 16)
            btx_util.write_bytes(b"\x7fELF" + b"\x00" * 16)
            with self.assertRaisesRegex((RuntimeError, Exception), "ENABLE_ZMQ help text"):
                self.module.main(
                    [
                        "--output-dir",
                        str(root / "out"),
                        "--version",
                        "0.34.5",
                        "--platform-id",
                        "linux-x86_64",
                        "--btxd",
                        str(btxd),
                        "--btx-cli",
                        str(btx_cli),
                        "--source-root",
                        str(source_root),
                    ]
                )

    def _abi_floor_fixture(self, root: pathlib.Path, *, qt_glibc: str, plugin_needs=None) -> list[str]:
        """A Linux GUI build: btxd at GLIBC_2.38, btx-qt and the Qt libraries at qt_glibc."""
        make_elf = load_make_elf()
        source_root = self._build_source_root(root)
        build = root / "build"
        build.mkdir()
        for name in ("btxd", "btx-cli", "btx-util"):
            (build / name).write_bytes(make_elf(["libc.so.6"], verneed={"libc.so.6": ["GLIBC_2.38"]}))
        (build / "btx-qt").write_bytes(make_elf(["libQt6Gui.so.6", "libc.so.6"], runpath="$ORIGIN/../lib/qt-private",
                                                verneed={"libc.so.6": [qt_glibc]}))

        def bundle_linux_qt(binary, lib_dir, shared_roots=None):
            plugin = lib_dir / "qt6" / "plugins" / "platforms" / "libqxcb.so"
            plugin.parent.mkdir(parents=True)
            for name in ("libQt6Gui.so.6", "libgnutls.so.30"):
                (lib_dir / name).write_bytes(make_elf(["libc.so.6"], verneed={"libc.so.6": [qt_glibc]},
                                                      executable=False))
            plugin.write_bytes(make_elf(["libstdc++.so.6", "libc.so.6"], executable=False,
                                        verneed=plugin_needs or {"libc.so.6": ["GLIBC_2.38"]}))

        self._stub_ship_gate()
        self.module._load_qt_bundle = lambda: types.SimpleNamespace(bundle_linux_qt=bundle_linux_qt)
        # objdump -T lists no dynamic symbols for these fixtures. Without
        # binutils the reader takes the version needs from the ELF itself.
        real_run = subprocess.run

        def no_binutils(command, *args, **kwargs):
            if command[0] in ("objdump", "readelf"):
                raise FileNotFoundError(command[0])
            return real_run(command, *args, **kwargs)

        patcher = mock.patch.object(subprocess, "run", side_effect=no_binutils)
        patcher.start()
        self.addCleanup(patcher.stop)
        return ["--output-dir", str(root / "out"), "--version", "0.34.16", "--platform-id", "linux-x86_64",
                "--btxd", str(build / "btxd"), "--btx-cli", str(build / "btx-cli"),
                "--source-root", str(source_root)]

    def test_packaging_refuses_any_elf_above_the_glibc_floor(self):
        # The 0.34.16 shape: packing read btxd alone, which needs GLIBC_2.38.
        with tempfile.TemporaryDirectory() as tmpdir, mock.patch.dict(os.environ):
            os.environ.pop("BTX_RELEASE_GLIBC_CEILING", None)
            root = pathlib.Path(tmpdir)
            argv = self._abi_floor_fixture(root, qt_glibc="GLIBC_2.43")
            with self.assertRaises(RuntimeError) as caught:
                self.module.main(argv)
            text = str(caught.exception)
            for name in ("libexec/btx-qt.real", "lib/qt-private/libQt6Gui.so.6", "lib/qt-private/libgnutls.so.30"):
                self.assertIn(f"{name} needs GLIBC_2.43", text)
            self.assertNotIn("btxd.real", text)
            self.assertNotIn("libqxcb", text)
            self.assertEqual(list((root / "out").iterdir()), [])
            # The ceiling has one source: raising it packs the same tree.
            os.environ["BTX_RELEASE_GLIBC_CEILING"] = "2.43"
            self.assertEqual(self.module.main(argv), 0)
            self.assertTrue((root / "out" / "btx-0.34.16-x86_64-linux-gnu.tar.gz").is_file())

    def test_packaging_refuses_a_host_glibcxx_need_above_the_floor(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            needs = {"libstdc++.so.6": ["GLIBCXX_3.4.33", "CXXABI_1.3.16"], "libc.so.6": ["GLIBC_2.38"]}
            argv = self._abi_floor_fixture(root, qt_glibc="GLIBC_2.38", plugin_needs=needs)
            with self.assertRaises(RuntimeError) as caught:
                self.module.main(argv)
            self.assertIn("lib/qt-private/qt6/plugins/platforms/libqxcb.so: needs "
                          "CXXABI_1.3.16 from the host's libstdc++.so.6 (floor CXXABI_1.3.15), "
                          "GLIBCXX_3.4.33 from the host's libstdc++.so.6 (floor GLIBCXX_3.4.32)",
                          str(caught.exception))
            self.assertNotIn("needs GLIBC_", str(caught.exception))

    def _qt_bundle_fixture(self, root: pathlib.Path, binary_qt: str, plugin_qt: str):
        # 0.34.16 shipped a Qt 5 btx-qt.real next to the Qt 6 xcb plugin that
        # qtpaths6 found. ldd, qtpaths and patchelf are replaced so this runs
        # on any host; only the Qt majors in the two ldd maps differ per test.
        bundle = self.module._load_qt_bundle()
        host = root / "host-libs"
        host.mkdir()

        def lib(name: str) -> pathlib.Path:
            path = host / name
            path.write_bytes(b"\x7fELF " + name.encode())
            return path

        binary = root / "libexec" / "btx-qt.real"
        binary.parent.mkdir()
        binary.write_bytes(b"\x7fELF btx-qt")
        plugins = root / "qt-plugins"
        (plugins / "platforms").mkdir(parents=True)
        plugin = plugins / "platforms" / "libqxcb.so"
        plugin.write_bytes(b"\x7fELF qxcb")
        maps = {
            binary: {
                f"libQt{binary_qt}Core.so.{binary_qt}": lib(f"libQt{binary_qt}Core.so.{binary_qt}"),
                f"libQt{binary_qt}Gui.so.{binary_qt}": lib(f"libQt{binary_qt}Gui.so.{binary_qt}"),
            },
            plugin: {f"libQt{plugin_qt}XcbQpa.so.{plugin_qt}": lib(f"libQt{plugin_qt}XcbQpa.so.{plugin_qt}")},
        }
        bundle._ldd_map = lambda path, required=None: dict(maps.get(pathlib.Path(path), {}))
        bundle._qt_plugins_root = lambda: plugins
        bundle._set_rpath = lambda path, rpath: None
        print_rpath = mock.patch.object(bundle.subprocess, "check_output", return_value="")
        print_rpath.start()
        self.addCleanup(print_rpath.stop)
        return bundle, binary, root / "lib" / "qt-private"

    def test_linux_qt_bundle_refuses_qt5_gui(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            bundle, binary, lib_dir = self._qt_bundle_fixture(root, "5", "6")
            with self.assertRaisesRegex(RuntimeError, "WITH_QT_VERSION=6"):
                bundle.bundle_linux_qt(binary, lib_dir)
            self.assertFalse((binary.parent / "qt.conf").exists())

    def test_linux_qt_bundle_refuses_plugin_from_other_qt_major(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            bundle, binary, lib_dir = self._qt_bundle_fixture(root, "6", "5")
            with self.assertRaisesRegex(RuntimeError, "Qt 5"):
                bundle.bundle_linux_qt(binary, lib_dir)
            self.assertFalse((binary.parent / "qt.conf").exists())

    def test_linux_qt_bundle_ships_matching_qt6_plugin(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            bundle, binary, lib_dir = self._qt_bundle_fixture(root, "6", "6")
            bundle.bundle_linux_qt(binary, lib_dir)
            self.assertTrue((lib_dir / "libQt6Core.so.6").is_file())
            self.assertTrue((lib_dir / "libQt6XcbQpa.so.6").is_file())
            self.assertTrue((lib_dir / "qt6" / "plugins" / "platforms" / "libqxcb.so").is_file())
            self.assertIn("Plugins = lib/qt-private/qt6/plugins", (binary.parent / "qt.conf").read_text(encoding="utf-8"))

    def _stage_linux_wrapper(self, root: pathlib.Path, *, glibc_sym: str = "GLIBC_2.99") -> pathlib.Path:
        bindir = root / "bin"
        libexec = root / "libexec"
        bindir.mkdir()
        libexec.mkdir()
        wrapper = bindir / "btxd"
        wrapper.write_text(self.module.wrapper_payload("btxd", "linux-x86_64"), encoding="utf-8")
        wrapper.chmod(0o755)
        real = libexec / "btxd.real"
        real.write_bytes(b"#!/bin/sh\necho should-not-run\n" + glibc_sym.encode() + b"\nGLIBCXX_3.4.99\n")
        real.chmod(0o755)
        tools = root / "tools"
        tools.mkdir()
        (tools / "ldd").write_text(
            "#!/bin/sh\n"
            "printf '%s\\n' "
            "'\\tlibc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x0)' "
            "'\\tlibstdc++.so.6 => /lib/x86_64-linux-gnu/libstdc++.so.6 (0x0)'\n",
            encoding="utf-8",
        )
        (tools / "getconf").write_text(
            "#!/bin/sh\n"
            "if [ \"$1\" = GNU_LIBC_VERSION ]; then echo 'glibc 2.35'; exit 0; fi\n"
            "exit 1\n",
            encoding="utf-8",
        )
        (tools / "ldd").chmod(0o755)
        (tools / "getconf").chmod(0o755)
        return wrapper

    def test_linux_wrapper_payload_checks_version_symbols(self):
        payload = self.module.wrapper_payload("btxd", "linux-x86_64")
        self.assertIsNotNone(payload)
        self.assertIn("objdump -T", payload)
        self.assertIn("GLIBC", payload)
        self.assertIn("GLIBCXX", payload)
        self.assertIn("GNU_LIBC_VERSION", payload)
        self.assertIn("BTX_GLIBC_PREFIX", payload)
        self.assertIn("ldd --version", payload)
        modeld = self.module.wrapper_payload("btx-modeld", "linux-x86_64")
        self.assertIn("objdump -T", modeld)
        self.assertNotIn("libsqlite3-0", modeld)

    def test_linux_wrapper_reports_glibc_version_mismatch(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            wrapper = self._stage_linux_wrapper(root)
            env = os.environ.copy()
            env["PATH"] = f"{root / 'tools'}:{env.get('PATH', '')}"
            env.pop("BTX_GLIBC_PREFIX", None)
            proc = subprocess.run(
                [str(wrapper), "--version"],
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            self.assertEqual(proc.returncode, 127)
            self.assertIn("GLIBC_2.99", proc.stderr)
            self.assertIn("2.35", proc.stderr)
            self.assertIn("version nodes", proc.stderr)
            self.assertNotIn("should-not-run", proc.stdout)

    def test_linux_wrapper_honors_btx_glibc_prefix(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = pathlib.Path(tmpdir)
            wrapper = self._stage_linux_wrapper(root)
            libdir = root / "glibc" / "usr" / "lib" / "x86_64-linux-gnu"
            libdir.mkdir(parents=True)
            loader = libdir / "ld-linux-x86-64.so.2"
            loader.write_text("#!/bin/sh\nprintf 'loader-ok\\n'\n", encoding="utf-8")
            loader.chmod(0o755)
            env = os.environ.copy()
            env["PATH"] = f"{root / 'tools'}:{env.get('PATH', '')}"
            env["BTX_GLIBC_PREFIX"] = str(root / "glibc")
            proc = subprocess.run(
                [str(wrapper), "--version"],
                capture_output=True,
                text=True,
                env=env,
                check=False,
            )
            self.assertEqual(proc.returncode, 0, proc.stderr)
            self.assertIn("loader-ok", proc.stdout)


def load_bundle_module():
    spec = importlib.util.spec_from_file_location("bundle_qt_gui", ROOT / "scripts/release/bundle_qt_gui.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

class BundleQtGuiTest(unittest.TestCase):
    def setUp(self):
        self.module = load_bundle_module()

    def _mac_deploy_fixture(self, diagnostic=""):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = pathlib.Path(tmp.name)
        binary = root / "btx-qt"
        binary.write_bytes(b"fixture")
        calls = []
        def invoke(args, **kwargs):
            calls.append(args)
            return subprocess.CompletedProcess(args, 0, "", diagnostic)
        with mock.patch.object(self.module, "_macdeployqt", return_value=pathlib.Path("/qt/bin/macdeployqt")), \
             mock.patch.object(self.module.subprocess, "run", side_effect=invoke), \
             mock.patch.object(self.module.subprocess, "check_call", side_effect=lambda args: calls.append(args)), \
             mock.patch.object(self.module.shutil, "which", return_value=None):
            result = self.module.deploy_macos_qt_app(binary, root / "release", "test")
        return result, calls

    def test_macos_deployment_searches_install_prefix_lib(self):
        result, calls = self._mac_deploy_fixture()
        self.assertTrue(result.is_file())
        self.assertIn("-libpath=/qt/lib", calls[0])

    def test_macos_deployment_rejects_reported_errors_with_zero_exit(self):
        with self.assertRaisesRegex(RuntimeError, "incomplete deployment"):
            self._mac_deploy_fixture("ERROR: Cannot resolve rpath QtSvg.framework\n")

    def test_macos_deployment_allows_ordinary_diagnostics(self):
        result, _ = self._mac_deploy_fixture("WARNING: informational message\n")
        self.assertTrue(result.is_file())

    def test_macos_deployment_removes_builder_rpath_before_signing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            binary = root / "btx-qt"
            binary.write_bytes(b"fixture")
            app = root / "release/btx-qt.app"
            jpeg = app / "Contents/Frameworks/libjpeg.8.dylib"

            def deploy(args, **kwargs):
                jpeg.parent.mkdir(parents=True)
                jpeg.write_bytes(b"\xcf\xfa\xed\xfe")
                (jpeg.parent / "libjpeg.dylib").symlink_to(jpeg.name)
                return subprocess.CompletedProcess(args, 0, "", "")

            def otool(args, **kwargs):
                if args[1] == "-l":
                    return ("Load command 1\n          cmd LC_RPATH\n      cmdsize 56\n"
                            "         path /opt/homebrew/Cellar/jpeg-turbo/3.2.1/lib (offset 12)\n"
                            "Load command 2\n          cmd LC_RPATH\n      cmdsize 48\n"
                            "         path @loader_path/../Frameworks (offset 12)\n")
                return ""

            with mock.patch.object(self.module, "_macdeployqt", return_value=pathlib.Path("/qt/bin/macdeployqt")), \
                 mock.patch.object(self.module.subprocess, "run", side_effect=deploy), \
                 mock.patch.object(self.module.subprocess, "check_output", side_effect=otool), \
                 mock.patch.object(self.module.subprocess, "check_call") as edit, \
                 mock.patch.object(self.module.shutil, "which", return_value="/usr/bin/codesign"):
                self.module.deploy_macos_qt_app(binary, root / "release", "test")

            self.assertEqual([call.args[0] for call in edit.call_args_list], [
                ["install_name_tool", "-delete_rpath", "/opt/homebrew/Cellar/jpeg-turbo/3.2.1/lib", str(jpeg)],
                ["codesign", "--force", "--deep", "--sign", "-", str(app)],
            ])

    def _plugin_dependency_recovery_fixture(self, tool_removed_path=False):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            binary = root / "btx-qt"
            binary.write_bytes(b"fixture")
            calls = []
            def deploy(args, **kwargs):
                calls.append(args)
                if len(calls) == 1:
                    plugin = root / "release/btx-qt.app/Contents/PlugIns/iconengines/plugin.dylib"
                    plugin.parent.mkdir(parents=True)
                    plugin.write_bytes(b"fixture")
                    return subprocess.CompletedProcess(args, 0, "", "ERROR: Cannot resolve rpath QtSvg.framework")
                return subprocess.CompletedProcess(args, 0, "", "")
            with mock.patch.object(self.module, "_macdeployqt", return_value=pathlib.Path("/qt/bin/macdeployqt")), \
                 mock.patch.object(self.module.subprocess, "run", side_effect=deploy), \
                 mock.patch.object(self.module.subprocess, "check_output", side_effect=["", "" if tool_removed_path else "path /qt/lib (offset 12)"]), \
                 mock.patch.object(self.module.subprocess, "check_call") as edit, \
                 mock.patch.object(self.module.shutil, "which", return_value=None):
                self.module.deploy_macos_qt_app(binary, root / "release", "test")
            self.assertEqual(len(calls), 2)
            self.assertIn("-no-plugins", calls[1])
            self.assertTrue(any(arg.startswith("-executable=") for arg in calls[1]))
            self.assertIn("-add_rpath", edit.call_args_list[0].args[0])
            deletes = [c for c in edit.call_args_list if "-delete_rpath" in c.args[0]]
            self.assertEqual(len(deletes), 0 if tool_removed_path else 1)

    def test_macos_plugin_only_frameworks_are_additional_roots(self):
        self._plugin_dependency_recovery_fixture(False)

    def test_macos_deployer_may_remove_temporary_rpath(self):
        self._plugin_dependency_recovery_fixture(True)

    def test_direct_private_dependency_survives_host_branch_cut(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            names = ("btx-qt", "libQt6Core.so.6", "libglib-2.0.so.0", "libshared.so.1", "libhost_only.so.1")
            paths = {n: root / n for n in names}
            for p in paths.values(): p.write_bytes(b"fixture")
            needed = {"btx-qt": ["libQt6Core.so.6", "libshared.so.1"],
                      "libQt6Core.so.6": ["libglib-2.0.so.0", "libshared.so.1"],
                      "libshared.so.1": [], "libglib-2.0.so.0": ["libhost_only.so.1"],
                      "libhost_only.so.1": []}
            # Every ldd response is flattened, including a dependency owned only by host GLib.
            flat = "\n".join(f"{n} => {p} (0x1)" for n, p in paths.items() if n != "btx-qt")
            def print_needed(path): return set(needed[path.name])
            with mock.patch.object(self.module.shutil, "which", return_value="/tool/patchelf"), \
                 mock.patch.object(self.module, "_needed", side_effect=print_needed, create=True), \
                 mock.patch.object(self.module.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, flat, "")):
                collected = self.module._collect_private_libs([paths["btx-qt"]])
            self.assertEqual(set(collected), {"libQt6Core.so.6", "libshared.so.1"})

    def test_missing_private_dependency_is_still_fatal(self):
        with mock.patch.object(self.module.shutil, "which", return_value="/tool/patchelf"), \
             mock.patch.object(self.module, "_needed", return_value={"libprivate.so.1"}, create=True), \
             mock.patch.object(self.module.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, "libprivate.so.1 => not found\n", "")):
            with self.assertRaisesRegex(RuntimeError, "missing libprivate.so.1"):
                self.module._ldd_map(pathlib.Path("fixture"))

    def test_static_root_does_not_require_dynamic_libraries(self):
        with mock.patch.object(self.module, "_needed", return_value=set(), create=True), \
             mock.patch.object(self.module.subprocess, "run") as ldd:
            self.assertEqual(self.module._ldd_map(pathlib.Path("static-fixture")), {})
        ldd.assert_not_called()

    def test_shared_query_does_not_acquire_unrelated_dependencies(self):
        with tempfile.TemporaryDirectory() as tmp:
            shared = pathlib.Path(tmp) / "libshared.so.1"
            shared.write_bytes(b"fixture")
            flat = f"libshared.so.1 => {shared} (0x1)\nlibunrelated.so.1 => not found\n"
            with mock.patch.object(self.module, "_needed", return_value={"libshared.so.1", "libunrelated.so.1"}, create=True), \
                 mock.patch.object(self.module.subprocess, "run", return_value=subprocess.CompletedProcess([], 1, flat, "unrelated dependency unavailable")):
                self.assertEqual(self.module._ldd_map(pathlib.Path("fixture"), {"libshared.so.1"}), {"libshared.so.1": shared})
                with self.assertRaises(RuntimeError):
                    self.module._ldd_map(pathlib.Path("fixture"))

    def test_host_desktop_services_are_not_copied(self):
        for name in ("libglib-2.0.so.0", "libgobject-2.0.so.0", "libgio-2.0.so.0", "libgmodule-2.0.so.0", "libgthread-2.0.so.0", "libdbus-1.so.3"):
            with self.subTest(name=name): self.assertTrue(self.module._host_soname(name))
        self.assertFalse(self.module._host_soname("libQt6Core.so.6"))

    def test_private_qt_paths_are_consistent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = pathlib.Path(tmp)
            binary = root / "libexec/btx-qt.real";binary.parent.mkdir();binary.write_bytes(b"qt")
            plugins = root / "builder/plugins"; (plugins / "platforms").mkdir(parents=True)
            (plugins / "platforms/libqxcb.so").write_bytes(b"plugin")
            library = root / "builder/libQt6Core.so.6";library.write_bytes(b"lib")
            with mock.patch.object(self.module, "_ldd_map", return_value={library.name: library}), \
                 mock.patch.object(self.module, "_qt_plugins_root", return_value=plugins), \
                 mock.patch.object(self.module, "_collect_private_libs", return_value={library.name: library}), \
                 mock.patch.object(self.module.subprocess, "check_output", return_value=""), \
                 mock.patch.object(self.module, "_set_rpath") as rpath:
                self.module.bundle_linux_qt(binary, root / "lib/qt-private")
            rpath.assert_any_call(binary, "$ORIGIN/../lib/qt-private:$ORIGIN/../lib")
            config = (binary.parent / "qt.conf").read_text()
            self.assertIn("Plugins = lib/qt-private/qt6/plugins", config)
            self.assertIn("Libraries = lib/qt-private", config)
            self.assertTrue((root / "lib/qt-private/qt6/plugins/platforms/libqxcb.so").is_file())


def load_python_bundle_module():
    spec = importlib.util.spec_from_file_location("bundle_python_runtime", ROOT / "scripts/release/bundle_python_runtime.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class BundlePythonRuntimeTest(unittest.TestCase):
    def setUp(self):
        self.module = load_python_bundle_module()
        self.make_elf = load_make_elf()
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = pathlib.Path(tmp.name)

    def _elf(self, path, **kwargs):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(self.make_elf(**kwargs))
        return path

    def test_linked_libpython_reads_dt_needed(self):
        linked = self._elf(self.root / "a", needed=["libc.so.6", "libpython3.12.so.1.0"])
        plain = self._elf(self.root / "b", needed=["libc.so.6"])
        stub = self.root / "c"; stub.write_text("daemon\n")
        self.assertEqual(self.module.linked_libpython(linked), "libpython3.12.so.1.0")
        self.assertIsNone(self.module.linked_libpython(plain))
        self.assertIsNone(self.module.linked_libpython(stub))

    def test_swapnet_imports_include_function_level_and_skip_own_package(self):
        package = self.root / "contrib/swapnet/swapnet"; package.mkdir(parents=True)
        (package / "a.py").write_text(
            "import os\nimport json, re as r\nfrom . import b\nfrom swapnet.x import y\n"
            "def f():\n    from cryptography.hazmat.primitives import hashes\n    import swapnet.z\n")
        self.assertEqual(self.module.swapnet_imports(self.root),
                         ["cryptography.hazmat.primitives", "json", "os", "re"])

    def test_repository_swapnet_sources_import_cryptography_and_sqlite3(self):
        names = self.module.swapnet_imports(ROOT)
        self.assertIn("sqlite3", names)
        self.assertTrue(any(name.startswith("cryptography.") for name in names), names)
        self.assertFalse(any(name.split(".")[0] == "swapnet" for name in names))

    def test_stdlib_copy_leaves_out_tests_gui_bytecode_and_outside_links(self):
        src = self.root / "stdlib"; out = self.root / "out"
        outside = self.root / "etc/sitecustomize.py"; outside.parent.mkdir(); outside.write_text("host policy\n")
        files = ["os.py", "__pycache__/os.cpython-312.pyc", "test/test_os.py", "tkinter/__init__.py",
                 "idlelib/idle.py", "config-3.12-x86_64-linux-gnu/Makefile", "json/__init__.py",
                 "json/__pycache__/x.pyc", "lib-dynload/_ssl.cpython-312-x86_64-linux-gnu.so",
                 "lib-dynload/readline.cpython-312-x86_64-linux-gnu.so",
                 "lib-dynload/_testcapi.cpython-312-x86_64-linux-gnu.so", "site-packages/foo.py"]
        for name in files:
            (src / name).parent.mkdir(parents=True, exist_ok=True)
            (src / name).write_text(name)
        (src / "sitecustomize.py").symlink_to(outside)
        (src / "_alias.py").symlink_to("os.py")
        (src / "linked").symlink_to(self.root / "etc", target_is_directory=True)
        skipped = self.module._copy_stdlib(src, out)
        copied = sorted(str(p.relative_to(out)) for p in out.rglob("*") if p.is_file())
        self.assertEqual(copied, ["_alias.py", "json/__init__.py",
                                  "lib-dynload/_ssl.cpython-312-x86_64-linux-gnu.so", "os.py"])
        self.assertFalse((out / "_alias.py").is_symlink())
        self.assertEqual(sorted(skipped), ["linked/", "sitecustomize.py"])

    def test_refuses_a_swapnet_btxd_without_a_shared_libpython(self):
        static = self._elf(self.root / "release/libexec/btxd.real", needed=["libc.so.6"],
                           extra=b"\0SwapNet: startup failed\0SwapNet Python initialization failed\0")
        with self.assertRaisesRegex(RuntimeError, "links no libpython shared library"):
            self.module.bundle_linux_python(static, self.root / "release", source_root=ROOT)
        plain = self._elf(self.root / "other/btxd.real", needed=["libc.so.6"])
        self.assertEqual(self.module.bundle_linux_python(plain, self.root / "other", source_root=ROOT), [])

    def test_third_party_roots_are_top_level_packages_and_modules(self):
        stdlib = self.root / "usr/lib/python3.12"; site = self.root / "usr/lib/python3/dist-packages"
        info = {"stdlib": str(stdlib), "lib_dynload": str(stdlib / "lib-dynload"), "modules": {
            "json": str(stdlib / "json/__init__.py"),
            "_ssl": str(stdlib / "lib-dynload/_ssl.cpython-312-x86_64-linux-gnu.so"),
            "cryptography.hazmat.primitives": str(site / "cryptography/hazmat/primitives/__init__.py"),
            "cryptography": str(site / "cryptography/__init__.py"),
            "_cffi_backend": str(site / "_cffi_backend.cpython-312-x86_64-linux-gnu.so")}}
        self.assertEqual(self.module._third_party_roots(info), {
            "cryptography": site / "cryptography",
            "_cffi_backend": site / "_cffi_backend.cpython-312-x86_64-linux-gnu.so"})

    def test_third_party_roots_include_packages_nested_below_stdlib(self):
        stdlib = self.root / "opt/python/lib/python3.12"
        dynload = stdlib / "lib-dynload"
        for directory in ("site-packages", "dist-packages"):
            with self.subTest(directory=directory):
                site = stdlib / directory
                info = {"stdlib": str(stdlib), "lib_dynload": str(dynload), "modules": {
                    "os": str(stdlib / "os.py"),
                    "json": str(stdlib / "json/__init__.py"),
                    "json.data": str(stdlib / "json/site-packages/data.py"),
                    "_ssl": str(dynload / "_ssl.cpython-312-x86_64-linux-gnu.so"),
                    "dynload_data": str(dynload / "site-packages/data.py"),
                    "cryptography.hazmat.primitives": str(site / "cryptography/hazmat/primitives/__init__.py"),
                    "cryptography": str(site / "cryptography/__init__.py"),
                    "_cffi_backend": str(site / "_cffi_backend.cpython-312-x86_64-linux-gnu.so")}}
                self.assertEqual(self.module._third_party_roots(info), {
                    "cryptography": site / "cryptography",
                    "_cffi_backend": site / "_cffi_backend.cpython-312-x86_64-linux-gnu.so"})

    def test_startup_sonames_leave_out_what_only_libpython_pulls_in(self):
        host = self.root / "host"
        libs = {name: self._elf(host / name, needed=needed, executable=False) for name, needed in (
            ("libpython3.12.so.1.0", ["libexpat.so.1", "libz.so.1", "libc.so.6"]),
            ("libsqlite3.so.0", ["libz.so.1", "libc.so.6"]),
            ("libexpat.so.1", ["libc.so.6"]), ("libz.so.1", ["libc.so.6"]))}
        btxd = self._elf(self.root / "btxd.real", needed=["libpython3.12.so.1.0", "libsqlite3.so.0", "libc.so.6"])
        def ldd_map(path, required=None):
            return {name: libs[name] for name in self.module._needed(path) if name in libs and (required is None or name in required)}
        self.module._qt_bundle = lambda: types.SimpleNamespace(_ldd_map=ldd_map, _host_soname=lambda n: n.startswith("libc."))
        self.assertEqual(self.module.startup_sonames(btxd, "libpython3.12.so.1.0"),
                         {"libsqlite3.so.0", "libz.so.1", "libc.so.6"})

    def test_install_library_accepts_identical_and_refuses_other_existing_copy(self):
        def fake_rpath(path, rpath):
            with open(path, "ab") as fh:
                fh.write(b"RUNPATH=" + rpath.encode())
        self.module._set_rpath = fake_rpath
        source = self.root / "host/libexpat.so.1"; source.parent.mkdir(); source.write_bytes(b"expat")
        dest = self.root / "lib/libexpat.so.1"
        self.module._install_library(source, dest, "$ORIGIN")
        self.assertEqual(dest.read_bytes(), b"expatRUNPATH=$ORIGIN")
        self.module._install_library(source, dest, "$ORIGIN")  # the Qt bundle's copy of the same file
        dest.write_bytes(b"other")
        with self.assertRaisesRegex(RuntimeError, "Conflicting packaged dependency libexpat.so.1"):
            self.module._install_library(source, dest, "$ORIGIN")

    def test_runtime_problems_names_a_soname_its_runpath_cannot_reach(self):
        release = self.root / "release"
        module = self._elf(release / "lib/python3.12/lib-dynload/_ctypes.so",
                           needed=["libffi.so.8", "libc.so.6", "libsqlite3.so.0"],
                           runpath="$ORIGIN/../../python-private:$ORIGIN/../..", executable=False)
        problems = self.module.runtime_problems(release, [module], {"libsqlite3.so.0"})
        self.assertEqual(problems, ["lib/python3.12/lib-dynload/_ctypes.so cannot reach libffi.so.8"])
        self._elf(release / "lib/python-private/libffi.so.8", executable=False)
        self.assertEqual(self.module.runtime_problems(release, [module], {"libsqlite3.so.0"}), [])

    def test_origin_rpath_is_relative_to_each_module(self):
        lib = self.root / "lib"
        elf = lib / "python3/dist-packages/cryptography/hazmat/bindings/_rust.abi3.so"
        self.assertEqual(self.module._origin_rpath(elf, lib / "python-private", lib),
                         "$ORIGIN/../../../../../python-private:$ORIGIN/../../../../..")

    def _refusal(self, **overrides):
        btxd = self._elf(self.root / "release/libexec/btxd.real", needed=["libpython3.12.so.1.0"])
        host = self.root / "host/lib"; host.mkdir(parents=True, exist_ok=True)
        (host / "libpython3.12.so.1.0").write_bytes(b"libpython")
        stdlib = self.root / "host/python3.12"; (stdlib / "lib-dynload").mkdir(parents=True, exist_ok=True)
        info = {"version": "3.12", "soname": "libpython3.12.so.1.0", "libdir": str(host),
                "prefix": str(self.root / "host"), "platlibdir": "lib", "stdlib": str(stdlib),
                "lib_dynload": str(stdlib / "lib-dynload"), "failed": [], "modules": {}}
        info.update(overrides)
        qt = types.SimpleNamespace(_ldd_map=lambda path, req=None: {"libpython3.12.so.1.0": host / "libpython3.12.so.1.0"},
                                   _host_soname=lambda name: name.startswith("libc."))
        self.module._qt_bundle = lambda: qt
        self.module.find_interpreter = lambda soname, explicit=None: "python3.12"
        self.module.probe_interpreter = lambda python, modules: info
        self.module.swapnet_imports = lambda source_root: ["sqlite3"]
        with self.assertRaises(RuntimeError) as ctx:
            self.module.bundle_linux_python(btxd, self.root / "release", source_root=ROOT)
        return str(ctx.exception)

    def test_refuses_an_interpreter_of_another_version(self):
        self.assertIn("is Python 3.13", self._refusal(version="3.13", soname="libpython3.13.so.1.0"))

    def test_refuses_an_interpreter_that_does_not_own_the_linked_library(self):
        other = self.root / "elsewhere"; other.mkdir()
        (other / "libpython3.12.so.1.0").write_bytes(b"another build")
        self.assertIn("btxd loads", self._refusal(libdir=str(other)))

    def test_refuses_when_a_swapnet_import_fails_on_the_host(self):
        self.assertIn("cryptography.hazmat.primitives (ModuleNotFoundError)",
                      self._refusal(failed=["cryptography.hazmat.primitives (ModuleNotFoundError)"]))

    def test_refuses_a_lib64_layout(self):
        self.assertIn("platlibdir 'lib64'", self._refusal(platlibdir="lib64"))

    def test_refuses_a_third_party_module_outside_the_prefix(self):
        outside = self.root / "home/.local/cryptography"; outside.mkdir(parents=True)
        (outside / "__init__.py").write_text("")
        message = self._refusal(modules={"cryptography": str(outside / "__init__.py")})
        self.assertIn("outside", message)
        self.assertIn("cryptography", message)

    def _stage_swapnet_wrapper(self, name="btxd", *, bundled=True):
        bindir = self.root / "bin"; libexec = self.root / "libexec"; tools = self.root / "tools"
        for d in (bindir, libexec, tools):
            d.mkdir(exist_ok=True)
        wrapper = bindir / name
        wrapper.write_text(load_module().wrapper_payload(name, "linux-x86_64"), encoding="utf-8")
        wrapper.chmod(0o755)
        real = libexec / f"{name}.real"
        real.write_text('#!/bin/sh\necho "NO_LEGACY=${CRYPTOGRAPHY_OPENSSL_NO_LEGACY-unset}"\n# GLIBC_2.2.5\n')
        real.chmod(0o755)
        (tools / "ldd").write_text("#!/bin/sh\nprintf '\\tlibc.so.6 => /lib/x86_64-linux-gnu/libc.so.6 (0x0)\\n'\n")
        (tools / "getconf").write_text("#!/bin/sh\n[ \"$1\" = GNU_LIBC_VERSION ] && echo 'glibc 2.39'\n")
        for tool in ("ldd", "getconf"):
            (tools / tool).chmod(0o755)
        if bundled:
            (self.root / "lib/python3.12").mkdir(parents=True, exist_ok=True)
            (self.root / "lib/python3.12/os.py").write_text("")
        return wrapper

    def _run_wrapper(self, wrapper, **extra):
        env = {k: v for k, v in os.environ.items() if k != "CRYPTOGRAPHY_OPENSSL_NO_LEGACY"}
        env["PATH"] = f"{self.root / 'tools'}:{env.get('PATH', '')}"
        env.pop("BTX_GLIBC_PREFIX", None)
        env.update(extra)
        proc = subprocess.run([str(wrapper)], capture_output=True, text=True, env=env, check=False)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        return proc.stdout.strip()

    def test_swapnet_wrapper_skips_the_legacy_provider_with_the_bundled_runtime(self):
        self.assertEqual(self._run_wrapper(self._stage_swapnet_wrapper()), "NO_LEGACY=1")

    def test_swapnet_wrapper_leaves_the_switch_alone_without_the_runtime(self):
        self.assertEqual(self._run_wrapper(self._stage_swapnet_wrapper(bundled=False)), "NO_LEGACY=unset")

    def test_swapnet_wrapper_keeps_an_operator_setting(self):
        wrapper = self._stage_swapnet_wrapper()
        self.assertEqual(self._run_wrapper(wrapper, CRYPTOGRAPHY_OPENSSL_NO_LEGACY="0"), "NO_LEGACY=0")

    def test_swapnet_wrapper_switch_reaches_the_private_glibc_loader(self):
        wrapper = self._stage_swapnet_wrapper()
        libdir = self.root / "glibc/usr/lib/x86_64-linux-gnu"; libdir.mkdir(parents=True)
        loader = libdir / "ld-linux-x86-64.so.2"
        loader.write_text('#!/bin/sh\necho "NO_LEGACY=${CRYPTOGRAPHY_OPENSSL_NO_LEGACY-unset}"\n')
        loader.chmod(0o755)
        self.assertEqual(self._run_wrapper(wrapper, BTX_GLIBC_PREFIX=str(self.root / "glibc")), "NO_LEGACY=1")

    def test_only_the_swapnet_binaries_get_the_switch(self):
        archive = load_module()
        for name in ("btxd", "btx-qt"):
            self.assertIn("CRYPTOGRAPHY_OPENSSL_NO_LEGACY=1", archive.wrapper_payload(name, "linux-x86_64"))
        for name in ("btx-cli", "btx-util", "btx-guardd", "btx-modeld", "btx-atlas"):
            self.assertNotIn("CRYPTOGRAPHY_OPENSSL_NO_LEGACY", archive.wrapper_payload(name, "linux-x86_64"))
        self.assertNotIn("@SWAPNET_ENV@", archive.wrapper_payload("btxd", "linux-x86_64"))

    def test_stage_release_tree_bundles_python_on_linux_only(self):
        archive = load_module()
        archive.verify_shipped_btxd = archive.verify_shipped_cli = archive.verify_shipped_helper = lambda path: None
        archive.set_linux_bundled_lib_runpath = lambda path: None
        calls = []
        fake = types.SimpleNamespace(bundle_linux_python=lambda real, release_root, source_root, python:
                                     calls.append((real.name, python)) or ["lib/libpython3.12.so.1.0", "lib/python3.12"])
        archive._load_python_bundle = lambda: fake
        source_root = self.root / "source-root"
        for relative in archive.SUPPORT_FILES:
            (source_root / relative).parent.mkdir(parents=True, exist_ok=True)
            (source_root / relative).write_text(relative)
        for name in ("btxd", "btx-cli", "btx-util", "btxd.exe", "btx-cli.exe", "btx-util.exe"):
            (self.root / name).write_text(name)
        _, included, _ = archive.stage_release_tree(
            version="29.2", platform_id="linux-x86_64", btxd_path=self.root / "btxd",
            btx_cli_path=self.root / "btx-cli", btx_util_path=None, matmul_metallib_path=None,
            oracle_metallib_path=None, metal_lib_dir=None, source_root=source_root,
            temp_root=self.root / "linux", python="/opt/py/bin/python3.12")
        self.assertEqual(calls, [("btxd.real", "/opt/py/bin/python3.12")])
        self.assertIn("lib/python3.12", included)
        archive.stage_release_tree(
            version="29.2", platform_id="windows-x86_64", btxd_path=self.root / "btxd.exe",
            btx_cli_path=self.root / "btx-cli.exe", btx_util_path=None, matmul_metallib_path=None,
            oracle_metallib_path=None, metal_lib_dir=None, source_root=source_root,
            temp_root=self.root / "windows")
        self.assertEqual(len(calls), 1)

    @unittest.skipUnless(sys.platform.startswith("linux") and shutil.which("cc") and shutil.which("patchelf")
                         and shutil.which("python3-config") and importlib.util.find_spec("cryptography"),
                         "native Linux ELF tools, python3-dev and cryptography required")
    def test_native_bundle_ships_a_runtime_the_staged_tree_can_import_from(self):
        flags = subprocess.check_output(["python3-config", "--embed", "--ldflags"], text=True).split()
        release = self.root / "release"; real = release / "libexec/btxd.real"; real.parent.mkdir(parents=True)
        source = self.root / "main.c"; source.write_text("int main(void) { return 0; }\n")
        subprocess.run(["cc", str(source), "-Wl,--no-as-needed", *flags, "-o", str(real)], check=True)
        soname = self.module.linked_libpython(real)
        if soname is None:
            self.skipTest("host python3-config links libpython statically")
        written = self.module.bundle_linux_python(real, release, source_root=ROOT, python=sys.executable)
        version = soname[len("libpython"):].split(".so")[0]
        lib = release / "lib"
        self.assertEqual(written[0], f"lib/{soname}")
        self.assertTrue((lib / f"python{version}/os.py").is_file())
        self.assertTrue((lib / f"python{version}/lib-dynload").is_dir())
        self.assertFalse((lib / f"python{version}/test").exists())
        self.assertFalse(list(lib.rglob("__pycache__")))
        self.assertFalse(list(lib.rglob("readline.*.so")))
        self.assertFalse((lib / f"python{version}/sitecustomize.py").exists())
        self.assertTrue(any(p.name == "cryptography" for p in lib.rglob("cryptography")))
        self.assertFalse([p for p in release.rglob("*") if p.is_symlink()])
        self.assertEqual(subprocess.check_output(["patchelf", "--print-rpath", str(lib / soname)], text=True).strip(),
                         "$ORIGIN")
        # Extension modules that needed a bundled library point at lib/python-private, then lib/.
        dynload = lib / f"python{version}/lib-dynload"
        patched = {p.name: subprocess.check_output(["patchelf", "--print-rpath", str(p)], text=True).strip()
                   for p in dynload.glob("*.so")}
        patched = {name: rpath for name, rpath in patched.items() if rpath}
        self.assertTrue(patched)
        self.assertEqual(set(patched.values()), {"$ORIGIN/../../python-private:$ORIGIN/../.."})
        self.assertTrue((lib / "python-private").is_dir())
        bundled = [p for p in lib.rglob("*") if self.module._is_shared_object_name(p) and self.module._is_elf(p)]
        self.assertEqual(self.module.runtime_problems(release, bundled, self.module.startup_sonames(real, soname)), [])
        # bundle_linux_python already imported the SwapNet list from the staged tree
        # (verify_staged_imports); a missing stdlib piece fails it.
        shutil.rmtree(lib / f"python{version}/json")
        with self.assertRaisesRegex(RuntimeError, "cannot import"):
            self.module.verify_staged_imports(sys.executable, release, ["json"])


if __name__ == "__main__":
    unittest.main()
